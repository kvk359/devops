/**
*  Database connection details
*/

var config = {
    "user": "sa",
    "password": "Bigfix@2018",
    "server": "localhost",
    "database": "TestDB",
    "driver": "msnodesqlv8",
    "port": 1433
  };

module.exports = config;
